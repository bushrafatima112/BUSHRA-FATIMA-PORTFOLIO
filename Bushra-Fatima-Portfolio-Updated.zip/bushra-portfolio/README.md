# Bushra Fatima — Portfolio Website

A responsive graphic design + front-end development portfolio built with HTML, CSS and vanilla JavaScript.

## Run locally
Open `index.html` in a browser. For a local server, use VS Code Live Server.

## Before publishing
1. In `index.html`, replace `YOUR-EMAIL@example.com` with your real email address.
2. Check project titles and descriptions, and update any details you want to personalize.
3. Keep the `assets` folder alongside `index.html`, `style.css` and `script.js`.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `bushra-portfolio`).
2. Upload the contents of this folder to the repository root — not the outer folder itself.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish and open the URL shown in the Pages settings.

## Included previous project
The `winza-store` folder contains the original Winza Store HTML, CSS and JavaScript files as a preserved project source. The portfolio showcases it as a front-end project card.
